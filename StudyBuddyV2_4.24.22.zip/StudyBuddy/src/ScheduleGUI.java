import java.util.ArrayList;

import javafx.scene.control.Button;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class ScheduleGUI extends BorderPane{
	
	private Button backButton = new Button("Back");
	private SchedulerPane schedulerPane;
	
	public ScheduleGUI() {
		
		schedulerPane = new SchedulerPane(backButton);
		this.setPrefSize(800, 600);
		this.setCenter(schedulerPane);
		
		this.backButton.setOnAction(e -> {
			schedulerPane.saveAndExit();
			AppMenuGUI appMenu = new AppMenuGUI();
			this.setCenter(appMenu);
			
		});
	}
}
