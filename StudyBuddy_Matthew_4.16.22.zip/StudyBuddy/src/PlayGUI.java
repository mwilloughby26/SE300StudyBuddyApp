import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class PlayGUI extends BorderPane{
	
	Pane centerPane = new Pane();
	
	public PlayGUI() {
		
		Button backBTN = new Button("BACK");
		backBTN.setStyle("-fx-background-color: #FFFFFF");
		backBTN.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		backBTN.setTranslateX(25);
		backBTN.setTranslateY(15); 
		
		Button RacerBTN = new Button(" PLAY\nRACER");
		RacerBTN.setStyle("-fx-background-color: #FFFFFF");
		RacerBTN.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		RacerBTN.setTranslateX(175);
		RacerBTN.setTranslateY(360);
		Image raceimage = new Image("img/racingGame.jpeg");
		ImageView raceimageView = new ImageView(raceimage);
		raceimageView.setX(135);
		raceimageView.setY(150);
		raceimageView.setFitHeight(200);
		raceimageView.setFitWidth(200);
	    getChildren().add(raceimageView);
	    
	    Button froggerBTN = new Button("   PLAY\nFROGGER");
	    froggerBTN.setStyle("-fx-background-color: #FFFFFF");
	    froggerBTN.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
	    froggerBTN.setTranslateX(480);
	    froggerBTN.setTranslateY(360);
		Image frogimage = new Image("img/forgger.jpeg");
		ImageView frogimageView = new ImageView(frogimage);
		frogimageView.setX(440);
		frogimageView.setY(150);
		frogimageView.setFitHeight(200);
	    frogimageView.setFitWidth(200);
	    getChildren().add(frogimageView);
	    
	    Label raceCostLBL = new Label("-10 points");
	    raceCostLBL.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
	    raceCostLBL.setTranslateX(185);
	    raceCostLBL.setTranslateY(425);
	    
	    Label frogCostLBL = new Label("-5 points");
	    frogCostLBL.setFont(Font.font("Verdana", FontWeight.BOLD, 12));
	    frogCostLBL.setTranslateX(510);
	    frogCostLBL.setTranslateY(425);
	    
	    Label pointsLBL = new Label("POINTS: 0");
	    pointsLBL.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
	    pointsLBL.setTranslateX(650);
	    pointsLBL.setTranslateY(15);
	    
		backBTN.setOnAction(e -> {
			AppMenuGUI appMenu = new AppMenuGUI();
			raceimageView.setVisible(false);
			frogimageView.setVisible(false);
		
			this.setCenter(appMenu);
			
		});  
		
		
		centerPane.getChildren().addAll(backBTN,RacerBTN,froggerBTN,raceCostLBL,frogCostLBL,pointsLBL);
		this.setCenter(centerPane);
		
	}
	
}