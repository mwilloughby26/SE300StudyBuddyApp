//*************************************************
// Class: ScheduleController
// Author: Matthew Willoughby
// Date Created: February 23, 2022
// Date Modified: March 21, 2022
//
// Purpose: 
//				
//
// Attributes:
//				
//
// Methods:
//				
//
//*******************************************************
import java.util.ArrayList;
import java.util.Collections;

public class ScheduleController {
	
//	private ArrayList<CalanderEvent> events = new ArrayList<CalanderEvent>();
	private int currentDay;
	private int currentMonth;
	private int currentYear;
	
	public ScheduleController() {
		
	}
	
	public void saveEvents() {
		
	}
	
	public void loadUserEvents() {
		
	}
	
	public void addEvent() {
		
	}
	
	public void modifyEvent() {
		
	}
	
	public void deleteEvent() {
		
	}
	
	public void loadCanvasEvents() {
		
	}
	
	/*
	public static void main(String[] args) {
		
	}
	*/
}