import java.time.LocalDate;

public class CalanderEvent {
	
	private String name;
	private String description;
	private LocalDate eventDate;
	private String associatedClass;
	private boolean isComplete;
	
	
	public CalanderEvent() {
		
	}

	
	public LocalDate getDate() {
		return eventDate;
	}

	public void setDate(String month, String day, String year) {
		this.eventDate = LocalDate.parse(year + "-" + month + "-" + day);
	}
	
	public void setDate(LocalDate localDate) {
		this.eventDate = localDate;
	}
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getAssociatedClass() {
		return associatedClass;
	}


	public void setAssociatedClass(String associatedClass) {
		this.associatedClass = associatedClass;
	}


	public boolean isComplete() {
		return isComplete;
	}


	public void setComplete(boolean isComplete) {
		this.isComplete = isComplete;
	}
	
}