import java.util.ArrayList;

import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class AppMenuGUI extends BorderPane{
	
	private Pane centerPane = new Pane();
	private StudyGUI studyMenuPane;
	private ScheduleGUI scheduleGUI;
	
	public AppMenuGUI(ArrayList<String> courses, ArrayList<String> assignments) {
		
		studyMenuPane = new StudyGUI(courses, assignments);
		scheduleGUI = new ScheduleGUI(courses, assignments);
		
		Button scheduleBTN = new Button("SCHEDULE");
		scheduleBTN.setStyle("-fx-background-color: #FFFFFF");
		scheduleBTN.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		scheduleBTN.setTranslateX(100);
		scheduleBTN.setTranslateY(250);
		
		Button studyBTN = new Button("STUDY");
		studyBTN.setStyle("-fx-background-color: #FFFFFF");
		studyBTN.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		studyBTN.setTranslateX(350);
		studyBTN.setTranslateY(250);
		
		Button playBTN = new Button("PLAY");
		playBTN.setStyle("-fx-background-color: #FFFFFF");
		playBTN.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		playBTN.setTranslateX(550);
		playBTN.setTranslateY(250);
		
		Button logoutBTN = new Button("LOGOUT");
		logoutBTN.setStyle("-fx-background-color: #FFFFFF");
		logoutBTN.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
		logoutBTN.setTranslateX(25);
		logoutBTN.setTranslateY(15);
		
		centerPane.getChildren().addAll(scheduleBTN,studyBTN,playBTN,logoutBTN);
		this.setCenter(centerPane);
		
		studyBTN.setOnAction(e -> {
			
			this.setCenter(studyMenuPane);
			
		});

		scheduleBTN.setOnAction(e -> {
		
			this.setCenter(scheduleGUI);
	
		});

		playBTN.setOnAction(e -> {
	
		});
		
		logoutBTN.setOnAction(e -> {
		
			SplashPaneGUI loginPane = new SplashPaneGUI();
			Button LoginBtn = new Button("LOGIN");
			Button quitBTN = new Button("X");
			loginPane.setLoginBTN(LoginBtn, quitBTN);
			loginPane.setLogoImage();
			this.setCenter(loginPane);
			
			LoginBtn.setOnAction(r -> {
				
				AppMenuGUI appPane = new AppMenuGUI(courses, assignments);
				this.setCenter(appPane);
				
			});
			
			quitBTN.setOnAction(r -> {
				
				Platform.exit();

			});
			
		});

		
	}
	
}